"""
Circle plot.

Uses a function to plot a circle.
"""

import matplotlib.pyplot as plt
from myproject import get_circle_plot

fig = get_circle_plot()
plt.show()
